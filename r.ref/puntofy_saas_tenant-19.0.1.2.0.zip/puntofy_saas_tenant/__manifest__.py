{
    "name": "SaaS Tenant",
    "version": "19.0.1.2.0",
    "summary": "The half that lives inside the customer's own database: it "
               "closes the public site when the subscription stops being paid, "
               "and enforces the plan's user limit",
    "description": """
SaaS Tenant
===========

This module goes **inside each customer's database**, not in yours. It is the
other half of **SaaS Provisioning**: that one decides, this one obeys.

It reads two system parameters that the central writes:

* ``saas.suspended`` &mdash; when it is on, the public website answers the
  closed page. **The back office keeps working**, on purpose: the customer who
  wants to fix their payment does it from where they already are. Visitors are
  never told there is a payment problem &mdash; that is between you and your
  customer, and telling theirs does them damage that is not theirs to take.
* ``saas.limit_users`` &mdash; how many internal users the plan includes. 0 is
  unlimited. Hitting it does not show a technical error: it says what the plan
  includes and where to change it.

Why a parameter and not an installation
---------------------------------------

Cutting a service off and giving it back has to be instant and reversible.
Uninstalling a module can fail half way; writing one parameter cannot. And this
module ships in the template, so the code is in every tenant from birth.

It is free, and it is meant to be: it is useless on its own.
""",
    "author": "Puntofy",
    "maintainer": "Puntofy",
    "website": "https://puntofy.com",
    "support": "dev@puntofy.com",
    "license": "LGPL-3",
    "category": "Sales/Subscriptions",
    "depends": ["website"],
    "data": ["views/templates.xml"],
    "post_init_hook": "post_init_hook",
    "images": [
        "static/description/banner.png",
    ],
    "installable": True,
    "application": False,
}
