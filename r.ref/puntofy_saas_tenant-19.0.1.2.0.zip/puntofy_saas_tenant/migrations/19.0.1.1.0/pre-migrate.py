"""The service-closed page changes its external id.

The reason is in `puntofy_subscriptions`' 19.0.1.2.0 migration. What is special
here: the view is INHERITED from other modules (`puntofy_shutdown` does it), and
a view resolves by its `key`, not only by its external id. Renaming one without
the other leaves the inheritance pointing at nothing, and what the visitor sees
is Odoo's default page: a 404 where the customer's notice should be.
"""

IDS = {"pagina_cerrada": "page_service_closed"}
MODULE = "puntofy_saas_tenant"


def migrate(cr, version):
    if not version:
        return
    for old, new in IDS.items():
        cr.execute("""
            UPDATE ir_model_data SET name = %s
             WHERE module = %s AND name = %s
               AND NOT EXISTS (SELECT 1 FROM ir_model_data
                                WHERE module = %s AND name = %s)
        """, (new, MODULE, old, MODULE, new))
        cr.execute("UPDATE ir_ui_view SET key = %s WHERE key = %s",
                   ("%s.%s" % (MODULE, new), "%s.%s" % (MODULE, old)))
