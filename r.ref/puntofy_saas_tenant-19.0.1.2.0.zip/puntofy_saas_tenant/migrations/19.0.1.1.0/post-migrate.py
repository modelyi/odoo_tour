"""Databases that ALREADY had this module installed never ran the hook.

`post_init_hook` runs on install and nowhere else: not on a `-u`, not on a
`-u all`. So the key added to the rename map on 2026-09-15 ---
`puntofy.limite_sucursales` -> `saas.limit_branches` --- would never reach a
store that was already running, and its branch limit would stay at whatever the
central wrote before the split.

It calls the hook rather than repeating its list: a second copy of that list
falls behind the day another key is added to it.
"""

from odoo import SUPERUSER_ID
from odoo.api import Environment

from odoo.addons.puntofy_saas_tenant.hooks import post_init_hook


def migrate(cr, version):
    if not version:
        return
    post_init_hook(Environment(cr, SUPERUSER_ID, {}))
